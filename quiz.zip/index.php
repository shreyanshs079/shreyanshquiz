<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
    <div class = "menu">


<a href="main.php" class="button">Take Quiz</a>
<a href="add.php" class="button">Add questions</a>
</div>
	</main>


	<footer>
			<div class="container">
				Copyright &copy; IT SERIES TUTOR
			</div>


	</footer>

</body>
</html>
